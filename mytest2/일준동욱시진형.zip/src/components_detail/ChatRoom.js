import React from 'react';

const ChatRoom = () => {
    return (
        <div>
            
        </div>
    );
};

export default ChatRoom;