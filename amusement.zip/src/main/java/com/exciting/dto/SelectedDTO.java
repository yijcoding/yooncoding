package com.exciting.dto;

import lombok.Data;

@Data
public class SelectedDTO {
	int amuse_id;
	String member_id;
}
