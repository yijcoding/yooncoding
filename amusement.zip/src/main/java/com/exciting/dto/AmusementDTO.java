package com.exciting.dto;

import lombok.Data;

@Data
public class AmusementDTO {
	private int amuse_id;
	private String a_name;
	private String a_country;
	private String a_time;
}
