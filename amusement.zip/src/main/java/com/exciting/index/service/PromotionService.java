package com.exciting.index.service;

import java.util.List;

import com.exciting.dto.PromotionDTO;

public interface PromotionService {
	public List<PromotionDTO> selectList();
}
