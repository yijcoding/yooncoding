package com.exciting.dto;

import lombok.Data;

@Data
public class PointDTO {
	
	int point_id;
	int m_point;
	int order_id;
	String member_id;

}
