package com.exciting.dto;

import lombok.Data;

@Data
public class MypointDTO {
	
	int point_id;
	double m_point;
	int order_id;
	String member_id;

}
