
// state 초기값
const initState ={
    num:"",
    content:"",
}

