export const emojiList = [
    { emoji: '😀', src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgDOF9QXLzGS_NHTBGgV9RPiBY8_QwVmHlN6vvCdrIvQ&s", alt: ":)", title: ":)" },
    { emoji: '😄', src: "https://em-content.zobj.net/thumbs/120/google/350/grinning-face-with-smiling-eyes_1f604.png", alt: "😄", title: ";" },
    { emoji: '😂', src: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Emojione_1F602.svg/167px-Emojione_1F602.svg.png", alt: "😂", title: ":P" },
    { emoji: '😅', src: "https://as2.ftcdn.net/v2/jpg/01/95/45/25/1000_F_195452530_bYg7cpLNVOSO9tHDv6gD5ixlAuYC6kTY.jpg", alt: "😅", title: "8D" },
    { emoji: '😱', src: "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcRYKBGcZI4LwEUKj7hG7IUIOS1LjdNtQnx-kt8gLXZPKR4TJ3aU", alt: "😱", title: ":(" },
    { emoji: '😵', src: "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSjhc7gkbcSy9YJX7ZP5QiP1WBMTkc3iJF0Bu_7vNof9WauDkQo", alt: "😵", title: "--;" }
];