package com.exciting.entities;

import java.io.Serializable;

import lombok.Data;

@Data
public class SelectedEntityId implements Serializable{
	private int amuse_id;
    private String member_id;
}
