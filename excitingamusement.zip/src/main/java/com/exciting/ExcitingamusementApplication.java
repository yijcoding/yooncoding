package com.exciting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcitingamusementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcitingamusementApplication.class, args);
	}

}
